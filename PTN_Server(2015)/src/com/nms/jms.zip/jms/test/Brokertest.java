package com.nms.jms.test;

import com.nms.jms.jmsMeanager.Broker;


public class Brokertest {
	public static void main(String[] args) throws Exception {
		Broker.init("applicationContext-jms-broker.xml");
		System.out.println("kaishi");
	}
}
